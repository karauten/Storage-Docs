# Azure Blob Storage 
1) Application and User Data
2) Backup and Archive Data    
3) Analytics Data  
4) HPC, IoT, and AI Data
